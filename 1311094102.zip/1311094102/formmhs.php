<!Doctype html>
<html>
 <head>
   <title>Form Mahasiswa</title>
 </head>
 <body>
 <form name=fmhs method=post>
 <table>
 <tr><td>NPM</td><td><input type=text name=npm></td></tr>
 <tr><td>Nama</td><td><input type=text name=nama></td></tr>
 <tr><td>Sex</td>
 <td><select name=sex>
      <option value="L">Laki-laki</option>
	  <option value="P">Perempuan</option>
 </td></tr>
 <tr><td>Tinggi Badan</td>
 <td><input type=number min=50 max=200 step=0.5 name=tb>&nbsp cm</td></tr>
 <tr><td>Tanggal Lahir</td>
 <td><input type=date name=tgllahir></td></tr>
 <tr><td colspan=2><input type=submit value="Simpan"
 name="bsimpan"></td></tr>
 </table>
 </form>
 </body>
</html>
<?php 
$koneksi=mysqli_connect("localhost","root","","1311094102");
if (isset($_POST['bsimpan'])) {
 $npm=$_POST['npm'];
 $nama=$_POST['nama'];
 $sex=$_POST['sex'];
 $tb=$_POST['tb'];
 $tgllahir=$_POST['tgllahir'];
 $sql="insert into mahasiswa 
       (NPM,Nama,JenisKelamin,TinggiBadan,
	    TanggalLahir)
	    values 
	   ('".$npm."','".$nama."','".$sex."',".$tb.",'".$tgllahir."')";
 $qsimpan=mysqli_query($koneksi,$sql);
 if ($qsimpan) {
    echo "<script>
	      alert('Rekord sudah disimpan !');
		  </script>";
 } else {
    echo "<script>
	      alert('Rekord belum disimpan !');
		  </script>";
 }
}
?>