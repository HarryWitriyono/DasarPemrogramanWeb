<!Doctype html>
<html>
 <head>
   <title>Form Hapus Mahasiswa</title>
 </head>
 <body>
 <form name=fmhs method=post>
 <table>
 <tr><td>NPM</td><td><input type=text name=npm></td></tr>
 <tr><td colspan=2><input type=submit value="Hapus"
 name="bhapus"></td></tr>
 </table>
 </form>
 </body>
</html>
<?php 
$koneksi=mysqli_connect("localhost","root","","1311094102");
if (isset($_POST['bhapus'])) {
 $npm=$_POST['npm'];
 $sql="delete from mahasiswa Where NPM='".$npm."'";
 $qsimpan=mysqli_query($koneksi,$sql);
 if ($qsimpan) {
    echo "<script>
	      alert('Rekord sudah dihapus !');
		  </script>";
 } else {
    echo "<script>
	      alert('Rekord belum dihapus !');
		  </script>";
 }
}
?>